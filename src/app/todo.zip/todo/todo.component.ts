import { Component, OnInit } from '@angular/core';
import { TodoItem } from '../todoInterface';



@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {

  todos = [];
  item = '';
  onChecked:boolean;
  btnClicked = false;
  indexList:number;

  constructor() {
   }

  ngOnInit(): void {
 
  }

  onClickBtn() {
    this.btnClicked != this.btnClicked;
    this.todos.push(this.item);
    console.log(this.todos);

  }

  onCheckboxClicked = (index:number, event:Event) => {
    if(this.todos[index] === index){
      this.onChecked = (<HTMLInputElement>event.target).checked;
      return this.onChecked;
    }
  }


}
